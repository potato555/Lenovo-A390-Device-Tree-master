android_device_lenovo_a390
============================

Full a390 device tree

Remember to give proper credits and links to the device tree you use to build ROMs/Recoveries

Thank you

MasterAwesome
